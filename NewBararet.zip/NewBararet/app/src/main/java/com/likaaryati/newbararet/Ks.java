package com.likaaryati.newbararet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Ks extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ks);
    }
    public void openHomec (View view){
        Intent intent = new Intent(this, MenuUtama.class);
        startActivity(intent);
    }
    public void openKsa (View view){
        Intent intent = new Intent(this, Ks1.class);
        startActivity(intent);
    }
    public void openKsb (View view){
        Intent intent = new Intent(this, Ks2.class);
        startActivity(intent);
    }
    public void openKsc (View view){
        Intent intent = new Intent(this,Ks3.class);
        startActivity(intent);
    }
}
