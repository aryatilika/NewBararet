package com.likaaryati.newbararet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class ggb extends AppCompatActivity {
WebView mainweb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ggb);
        mainweb = findViewById(R.id.mainweb);
        mainweb.setWebChromeClient(new WebChromeClient());
        mainweb.getSettings().setJavaScriptEnabled(true);
        mainweb.loadUrl("https://www.geogebra.org/classic/rcmg8res");
//        Buat Download
    }
}
