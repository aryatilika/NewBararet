package com.likaaryati.newbararet;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Barit extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barit);
    }
    public void openPolab (View view){
        Intent intent = new Intent(this, Polabilangan.class);
        startActivity(intent);
    }
    public void openBarisarit (View view){
        Intent i = new Intent(this, Baarit.class);
        startActivity(i);
    }
    public void openSuku (View view){
        Intent intent = new Intent(this, Sukutengah.class);
        startActivity(intent);
    }
    public void openDeretarit (View view){
        Intent intent = new Intent(this, Deretarit.class);
        startActivity(intent);
    }
    public void openSuba (View view){
        Intent intent = new Intent(this, Materi.class);
        startActivity(intent);
    }
    //Kode Keluar Aplikasi
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Keluar Aplikasi")
                .setMessage("Apakah anda yakin ingin keluar dari aplikasi?")
                .setPositiveButton("Yakin", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("Tidak", null)
                .show();
    }
}
