package com.likaaryati.newbararet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class Sukutengah extends AppCompatActivity {
    WebView mainweb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sukutengah);
        mainweb = findViewById(R.id.mainweb);
        mainweb.setWebChromeClient(new WebChromeClient());
        mainweb.getSettings().setJavaScriptEnabled(true);
        mainweb.loadUrl("file:///android_asset/SukuTengah.html");
    }
}
