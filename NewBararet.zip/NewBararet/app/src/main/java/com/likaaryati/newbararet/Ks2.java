package com.likaaryati.newbararet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class Ks2 extends AppCompatActivity {
    WebView mainweb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ks2);
        mainweb = findViewById(R.id.mainweb);
        mainweb.setWebChromeClient(new WebChromeClient());
        mainweb.getSettings().setJavaScriptEnabled(true);
        mainweb.loadUrl("file:///android_asset/LembarKerja2.html");
        mainweb.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimetype,
                                        long contentLength) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
    }

    public void openGgb (View view){
        Intent i = new Intent(this, ggb.class);
        startActivity(i);
    }
}
