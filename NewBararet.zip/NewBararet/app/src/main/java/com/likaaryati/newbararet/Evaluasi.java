package com.likaaryati.newbararet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Evaluasi extends AppCompatActivity {
    WebView mainweb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evaluasi);
        mainweb = findViewById(R.id.mainweb);
        mainweb.setWebChromeClient(new WebChromeClient());
        mainweb.getSettings().setJavaScriptEnabled(true);
        mainweb.loadUrl("https://quizizz.com/join");
    }
}
