package com.likaaryati.newbararet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class Anuitas extends AppCompatActivity {
    WebView mainweb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anuitas);
        mainweb = findViewById(R.id.mainweb);
        mainweb.setWebChromeClient(new WebChromeClient());
        mainweb.getSettings().setJavaScriptEnabled(true);
        mainweb.loadUrl("file:///android_asset/Anuitas.html");
    }
}
