package com.likaaryati.newbararet;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;

public class Bageo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bageo);
    }
    public void openBarisgeo (View view){
        Intent intent = new Intent(this, Barisgeo.class);
        startActivity(intent);
    }
    public void openDeretgeo (View view){
        Intent intent = new Intent(this, Deretgeo.class);
        startActivity(intent);
    }
    public void openDeretgeotak (View view){
        Intent intent = new Intent(this, Deretgeoth.class);
        startActivity(intent);
    }
    public void openPertumbuhan (View view){
        Intent intent = new Intent(this, Pertumbuhan.class);
        startActivity(intent);
    }
    public void openBunga (View view){
        Intent intent = new Intent(this, Bungamajemuk.class);
        startActivity(intent);
    }
    public void openPeluruhan (View view){
        Intent intent = new Intent(this, Peluruhan.class);
        startActivity(intent);
    }
    public void openAnuitas (View view){
        Intent intent = new Intent(this, Anuitas.class);
        startActivity(intent);
    }
    public void openSubb (View view){
        Intent intent = new Intent(this, Materi.class);
        startActivity(intent);
    }
    //Kode Keluar Aplikasi
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Keluar Aplikasi")
                .setMessage("Apakah anda yakin ingin keluar dari aplikasi?")
                .setPositiveButton("Yakin", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("Tidak", null)
                .show();
    }
}
