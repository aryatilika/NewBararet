package com.likaaryati.newbararet;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MenuUtama extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama);
    }
    public void openMateri (View view){
        Intent intent = new Intent(this, Materi.class);
        finish();
        startActivity(intent);
    }
    public void openkdipk (View view) {
        Intent intent = new Intent(this, Kd.class);
        finish();
        startActivity(intent);
    }
    public void openLk (View view) {
        Intent intent = new Intent(this, Ks.class);
        finish();
        startActivity(intent);
    }
    public void openPpenggunaan (View view) {
        Intent intent = new Intent(this, Ppengguna.class);
        finish();
        startActivity(intent);
    }
    public void openEval (View view) {
        Intent intent = new Intent(this, Evaluasi.class);
        startActivity(intent);
    }
    public void openProfil (View view) {
        Intent intent = new Intent(this, Profil.class);
        finish();
        startActivity(intent);
    }
    //Kode Keluar Aplikasi
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Keluar Aplikasi")
                .setMessage("Apakah anda yakin ingin keluar dari aplikasi?")
                .setPositiveButton("Yakin", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("Tidak", null)
                .show();
    }
}
